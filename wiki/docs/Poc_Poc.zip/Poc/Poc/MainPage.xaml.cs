﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using Obtics;
using Obtics.Values;

namespace Poc
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            for (int i = 0; i < 10; ++i)
                _Integers.Add(_Rnd.Next(100));

            _Timer.Interval = new TimeSpan(0, 0, 2);
            _Timer.Tick += new EventHandler(_Timer_Tick);
            _Timer.Start();
        }

        void _Timer_Tick(object sender, EventArgs e)
        { _Integers[_Rnd.Next(10)] = _Rnd.Next(100); }

        Random _Rnd = new Random();
        System.Windows.Threading.DispatcherTimer _Timer = new System.Windows.Threading.DispatcherTimer();

        ObservableCollection<int> _Integers = new ObservableCollection<int>();

        public IValueProvider<int> Sum
        { get { return ExpressionObserver.Execute(_Integers, c => c.Sum()).Concrete(); } }
    }
}
